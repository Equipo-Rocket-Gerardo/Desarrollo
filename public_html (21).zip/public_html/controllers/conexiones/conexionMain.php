<?php
// simple conexion a la base de datos
function connects(){
	return new mysqli("localhost","id20540950_eltioessus","R^oY=SP33fs?Yr~9","id20540950_coffeeshop");
};


?>