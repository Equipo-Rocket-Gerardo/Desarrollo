
<?php

// Se crea la conexion con la base datos:
// Servidor, Usuario, Contraseña y la base de datos utilizada
$conexion = mysqli_connect("localhost","id20540950_eltioessus","R^oY=SP33fs?Yr~9","id20540950_coffeeshop"); 

// Checa si la conexion se ralizo
if($conexion){
    //echo "se realizo correctamente la conexion";
}else{
    //echo "no se realizo correctamente la conexion";
}

?>
