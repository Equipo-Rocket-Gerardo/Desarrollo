<?php 
    if(isset($_POST['submit'])){
        if(empty($apPaterno)){
            echo "<p> falta el apellido pa </p>";
        }
    }
?>